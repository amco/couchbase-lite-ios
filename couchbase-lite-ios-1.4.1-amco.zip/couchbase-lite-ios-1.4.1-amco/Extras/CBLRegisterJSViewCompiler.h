//
//  CBLRegisterJSViewCompiler.h
//  CouchbaseLite
//
//  Created by Chris Anderson on 7/10/13.
//  Copyright (c) 2013 Couchbase, Inc. All rights reserved.
//

void CBLRegisterJSViewCompiler(void);
